
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <title>CAT tool</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="../assets/css/bootstrap.css" rel="stylesheet">
    <style type="text/css">
      body {
        padding-top: 20px;
        padding-bottom: 40px;
      }

      /* Custom container */
      .container-narrow {
        margin: 0 auto;
        max-width: 700px;
      }
      .container-narrow > hr {
        margin: 30px 0;
      }

      /* Main marketing message and sign up button */
      .jumbotron {
        margin: 60px 0;
        text-align: center;
      }
      .jumbotron h1 {
        font-size: 72px;
        line-height: 1;
      }
      .jumbotron .btn {
        font-size: 21px;
        padding: 14px 24px;
      }

      /* Supporting marketing content */
      .marketing {
        margin: 60px 0;
      }
      .marketing p + h4 {
        margin-top: 28px;
      }
    </style>
    <link href="../assets/css/bootstrap-responsive.css" rel="stylesheet">

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="../assets/js/html5shiv.js"></script>
    <![endif]-->

    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
      <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
                    <link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">
                                   <link rel="shortcut icon" href="../assets/ico/favicon.png">
  </head>

  <body>

    <div class="container-narrow">

      <div class="masthead">
        <ul class="nav nav-pills pull-right">
          <li class="active"><a href="#">Home</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
        <h3 class="muted">CAT tool</h3>
      </div>

      <hr>

      <div class="jumbotron">
        <h1>Hello CAT tool!</h1>
        <p class="lead">CAT平台旨在帮助译者提高翻译效率，提供翻译记忆库，术语库等翻译过程中提升翻译质量，减少重复劳动，保持一致性的必备语言资产，与此同时，提供在线词典及机器翻译等服务，提高翻译效率。此外，平台还可以起到连接作用，翻译团队可以利用平台合作项目，分配任务，互相审校。</p>
        <a class="btn btn-large btn-success" href="#">Sign up today</a>
      </div>

      <hr>

      <div class="row-fluid marketing">
        <div class="span6">
          <h4>实现目标</h4>
          <p>减少重复翻译；提升翻译质量；促进团队合作；方便翻译教学；良好的人机交互界面，操作简便；</p>

          <h4>用户特点</h4>
          <p>本系统的最终用户是面向教师和学生，主要用于翻译教学工作。系统维护人员是熟悉操作系统和数据库的专业人员，即小组组员。</p>

          <h4>功能简介</h4>
          <p>中英对照翻译，翻译对齐功能，可以对文档进行有效分割，形成翻译单元，并且在翻译界面能够满足用户对于在线词典和机器翻译的需求。</p>
        </div>

        <div class="span6">
          <h4>功能简介</h4>
          <p>翻译记忆库，它是一个数据库，存储以前翻译过的句子、段落或文本句段。并在翻译新文档时自动建议 TM 中存储的相同或类似的匹配。这意味着以前翻译过的句子、段落或文本句段不需要重新翻译。</p>

          <h4>功能简介</h4>
          <p>术语库，可以提前导入术语表，也可以在翻译时添加术语，可以对术语进行增删改的操作，促进术语标准化，保证翻译一致性。</p>

          <h4>功能简介</h4>
          <p>学生团队合作功能，学生可以在平台上组成项目团队，分配翻译任务，互相审校。教师分配任务功能，教师可以利用平台布置翻译作业，设置DDL，可以是个人作业也可以是小组作业，并且能够随时查看翻译进度。</p>
        </div>
      </div>

      <hr>

      <div class="footer">
        <p>&copy; 各种Pre小分队</p>
      </div>

    </div> <!-- /container -->

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/transition.js"></script>
    <script src="../assets/js/alert.js"></script>
    <script src="../assets/js/modal.js"></script>
    <script src="../assets/js/dropdown.js"></script>
    <script src="../assets/js/scrollspy.js"></script>
    <script src="../assets/js/tab.js"></script>
    <script src="../assets/js/tooltip.js"></script>
    <script src="../assets/js/popover.js"></script>
    <script src="../assets/js/button.js"></script>
    <script src="../assets/js/collapse.js"></script>
    <script src="../assets/js/carousel.js"></script>
    <script src="../assets/js/typeahead.js"></script>

  </body>
</html>
